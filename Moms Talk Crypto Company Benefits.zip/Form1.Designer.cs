﻿
namespace Moms_Talk_Crypto_Company_Benefits
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MTCTitlebutton = new System.Windows.Forms.Button();
            this.Salarylabel1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CheckBonusbutton1 = new System.Windows.Forms.Button();
            this.EnterYourAgelabel1 = new System.Windows.Forms.Label();
            this.VacationDaysbutton1 = new System.Windows.Forms.Button();
            this.JackPacklabel1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SalaryDisclosurelabel1 = new System.Windows.Forms.Label();
            this.SalaryDisclosure6label1 = new System.Windows.Forms.Label();
            this.SalaryDisclosure2label1 = new System.Windows.Forms.Label();
            this.BonusGuidelabel1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Percentagelabel1 = new System.Windows.Forms.Label();
            this.SalarywithBonuslabel1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.FindOutBonuslabel1 = new System.Windows.Forms.Label();
            this.NeedExtraDaysVacationlabel1 = new System.Windows.Forms.Label();
            this.dobdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.CurrentDatelabel1 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.ExtraVacationlabel1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.CheckAcuBonusbutton2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.calculateptodaysbutton2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MTCTitlebutton
            // 
            this.MTCTitlebutton.BackColor = System.Drawing.Color.LightCyan;
            this.MTCTitlebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MTCTitlebutton.Location = new System.Drawing.Point(140, 3);
            this.MTCTitlebutton.Name = "MTCTitlebutton";
            this.MTCTitlebutton.Size = new System.Drawing.Size(457, 69);
            this.MTCTitlebutton.TabIndex = 0;
            this.MTCTitlebutton.Text = "Moms Talk Crypto Company Benefits";
            this.MTCTitlebutton.UseVisualStyleBackColor = false;
            this.MTCTitlebutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // Salarylabel1
            // 
            this.Salarylabel1.AutoSize = true;
            this.Salarylabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salarylabel1.Location = new System.Drawing.Point(8, 230);
            this.Salarylabel1.Name = "Salarylabel1";
            this.Salarylabel1.Size = new System.Drawing.Size(110, 13);
            this.Salarylabel1.TabIndex = 1;
            this.Salarylabel1.Text = "Enter Your Salary:";
            this.Salarylabel1.Click += new System.EventHandler(this.Salarylabel1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(127, 227);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // CheckBonusbutton1
            // 
            this.CheckBonusbutton1.BackColor = System.Drawing.Color.LightCyan;
            this.CheckBonusbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBonusbutton1.ForeColor = System.Drawing.Color.DarkGreen;
            this.CheckBonusbutton1.Location = new System.Drawing.Point(127, 307);
            this.CheckBonusbutton1.Name = "CheckBonusbutton1";
            this.CheckBonusbutton1.Size = new System.Drawing.Size(121, 60);
            this.CheckBonusbutton1.TabIndex = 3;
            this.CheckBonusbutton1.Text = "Calculate Bonus";
            this.CheckBonusbutton1.UseVisualStyleBackColor = false;
            this.CheckBonusbutton1.Click += new System.EventHandler(this.CheckBonusbutton1_Click);
            // 
            // EnterYourAgelabel1
            // 
            this.EnterYourAgelabel1.AutoSize = true;
            this.EnterYourAgelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterYourAgelabel1.Location = new System.Drawing.Point(325, 195);
            this.EnterYourAgelabel1.Name = "EnterYourAgelabel1";
            this.EnterYourAgelabel1.Size = new System.Drawing.Size(195, 13);
            this.EnterYourAgelabel1.TabIndex = 4;
            this.EnterYourAgelabel1.Text = "Enter Your DOB (MM/DD/YYYY):";
            this.EnterYourAgelabel1.Click += new System.EventHandler(this.EnterYourAgelabel1_Click);
            // 
            // VacationDaysbutton1
            // 
            this.VacationDaysbutton1.BackColor = System.Drawing.Color.LightCyan;
            this.VacationDaysbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VacationDaysbutton1.Location = new System.Drawing.Point(512, 244);
            this.VacationDaysbutton1.Name = "VacationDaysbutton1";
            this.VacationDaysbutton1.Size = new System.Drawing.Size(124, 57);
            this.VacationDaysbutton1.TabIndex = 6;
            this.VacationDaysbutton1.Text = "Calculate PTO Days";
            this.VacationDaysbutton1.UseVisualStyleBackColor = false;
            this.VacationDaysbutton1.Click += new System.EventHandler(this.VacationDaysbutton1_Click);
            // 
            // JackPacklabel1
            // 
            this.JackPacklabel1.AutoSize = true;
            this.JackPacklabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JackPacklabel1.Location = new System.Drawing.Point(427, 434);
            this.JackPacklabel1.Name = "JackPacklabel1";
            this.JackPacklabel1.Size = new System.Drawing.Size(281, 16);
            this.JackPacklabel1.TabIndex = 7;
            this.JackPacklabel1.Text = "Click \"JackPot\" To Win Extra PTO Days";
            this.JackPacklabel1.Click += new System.EventHandler(this.JackPacklabel1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightCyan;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(503, 453);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 49);
            this.button1.TabIndex = 8;
            this.button1.Text = "JACKPOT!!!";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // SalaryDisclosurelabel1
            // 
            this.SalaryDisclosurelabel1.AutoSize = true;
            this.SalaryDisclosurelabel1.BackColor = System.Drawing.Color.White;
            this.SalaryDisclosurelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryDisclosurelabel1.Location = new System.Drawing.Point(36, 418);
            this.SalaryDisclosurelabel1.Name = "SalaryDisclosurelabel1";
            this.SalaryDisclosurelabel1.Size = new System.Drawing.Size(289, 16);
            this.SalaryDisclosurelabel1.TabIndex = 9;
            this.SalaryDisclosurelabel1.Text = "*Salary Less Than $80,000 BONUS = 4%.";
            // 
            // SalaryDisclosure6label1
            // 
            this.SalaryDisclosure6label1.AutoSize = true;
            this.SalaryDisclosure6label1.BackColor = System.Drawing.Color.White;
            this.SalaryDisclosure6label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryDisclosure6label1.Location = new System.Drawing.Point(8, 453);
            this.SalaryDisclosure6label1.Name = "SalaryDisclosure6label1";
            this.SalaryDisclosure6label1.Size = new System.Drawing.Size(349, 16);
            this.SalaryDisclosure6label1.TabIndex = 10;
            this.SalaryDisclosure6label1.Text = "*Salary Between $80,000 - $100,000 BONUS = 6%.";
            // 
            // SalaryDisclosure2label1
            // 
            this.SalaryDisclosure2label1.AutoSize = true;
            this.SalaryDisclosure2label1.BackColor = System.Drawing.Color.White;
            this.SalaryDisclosure2label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryDisclosure2label1.Location = new System.Drawing.Point(36, 486);
            this.SalaryDisclosure2label1.Name = "SalaryDisclosure2label1";
            this.SalaryDisclosure2label1.Size = new System.Drawing.Size(306, 16);
            this.SalaryDisclosure2label1.TabIndex = 11;
            this.SalaryDisclosure2label1.Text = "*Salary Greater than $100,000 BONUS = 2%";
            // 
            // BonusGuidelabel1
            // 
            this.BonusGuidelabel1.AutoSize = true;
            this.BonusGuidelabel1.BackColor = System.Drawing.Color.LightCyan;
            this.BonusGuidelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BonusGuidelabel1.Location = new System.Drawing.Point(137, 389);
            this.BonusGuidelabel1.Name = "BonusGuidelabel1";
            this.BonusGuidelabel1.Size = new System.Drawing.Size(102, 15);
            this.BonusGuidelabel1.TabIndex = 12;
            this.BonusGuidelabel1.Text = "BONUS GUIDE";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2",
            "4",
            "6"});
            this.comboBox1.Location = new System.Drawing.Point(127, 191);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(168, 21);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Percentagelabel1
            // 
            this.Percentagelabel1.AutoSize = true;
            this.Percentagelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Percentagelabel1.Location = new System.Drawing.Point(8, 195);
            this.Percentagelabel1.Name = "Percentagelabel1";
            this.Percentagelabel1.Size = new System.Drawing.Size(116, 13);
            this.Percentagelabel1.TabIndex = 14;
            this.Percentagelabel1.Text = "Select Percentage:";
            // 
            // SalarywithBonuslabel1
            // 
            this.SalarywithBonuslabel1.AutoSize = true;
            this.SalarywithBonuslabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalarywithBonuslabel1.Location = new System.Drawing.Point(8, 263);
            this.SalarywithBonuslabel1.Name = "SalarywithBonuslabel1";
            this.SalarywithBonuslabel1.Size = new System.Drawing.Size(183, 13);
            this.SalarywithBonuslabel1.TabIndex = 15;
            this.SalarywithBonuslabel1.Text = "Salary + BONUS Total Amount:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(192, 260);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(103, 20);
            this.textBox2.TabIndex = 16;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // FindOutBonuslabel1
            // 
            this.FindOutBonuslabel1.AutoSize = true;
            this.FindOutBonuslabel1.BackColor = System.Drawing.Color.LightCyan;
            this.FindOutBonuslabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindOutBonuslabel1.Location = new System.Drawing.Point(77, 167);
            this.FindOutBonuslabel1.Name = "FindOutBonuslabel1";
            this.FindOutBonuslabel1.Size = new System.Drawing.Size(162, 16);
            this.FindOutBonuslabel1.TabIndex = 17;
            this.FindOutBonuslabel1.Text = "Find Out Your BONUS:";
            this.FindOutBonuslabel1.Click += new System.EventHandler(this.FindOutBonuslabel1_Click);
            // 
            // NeedExtraDaysVacationlabel1
            // 
            this.NeedExtraDaysVacationlabel1.AutoSize = true;
            this.NeedExtraDaysVacationlabel1.BackColor = System.Drawing.Color.LightCyan;
            this.NeedExtraDaysVacationlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NeedExtraDaysVacationlabel1.Location = new System.Drawing.Point(393, 167);
            this.NeedExtraDaysVacationlabel1.Name = "NeedExtraDaysVacationlabel1";
            this.NeedExtraDaysVacationlabel1.Size = new System.Drawing.Size(283, 16);
            this.NeedExtraDaysVacationlabel1.TabIndex = 18;
            this.NeedExtraDaysVacationlabel1.Text = "Find Out How Much PTO days you have:";
            this.NeedExtraDaysVacationlabel1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dobdateTimePicker1
            // 
            this.dobdateTimePicker1.CustomFormat = "MM-dd-yyyy";
            this.dobdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dobdateTimePicker1.Location = new System.Drawing.Point(526, 192);
            this.dobdateTimePicker1.Name = "dobdateTimePicker1";
            this.dobdateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dobdateTimePicker1.TabIndex = 19;
            this.dobdateTimePicker1.ValueChanged += new System.EventHandler(this.dobdateTimePicker1_ValueChanged);
            // 
            // CurrentDatelabel1
            // 
            this.CurrentDatelabel1.AutoSize = true;
            this.CurrentDatelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentDatelabel1.Location = new System.Drawing.Point(343, 218);
            this.CurrentDatelabel1.Name = "CurrentDatelabel1";
            this.CurrentDatelabel1.Size = new System.Drawing.Size(177, 13);
            this.CurrentDatelabel1.TabIndex = 20;
            this.CurrentDatelabel1.Text = "Current Date (MM/DD/YYYY):";
            this.CurrentDatelabel1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "MM-dd-yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(528, 218);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 21;
            // 
            // ExtraVacationlabel1
            // 
            this.ExtraVacationlabel1.AutoSize = true;
            this.ExtraVacationlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraVacationlabel1.Location = new System.Drawing.Point(427, 319);
            this.ExtraVacationlabel1.Name = "ExtraVacationlabel1";
            this.ExtraVacationlabel1.Size = new System.Drawing.Size(124, 13);
            this.ExtraVacationlabel1.TabIndex = 22;
            this.ExtraVacationlabel1.Text = "Paid-Time Off Days: ";
            this.ExtraVacationlabel1.Click += new System.EventHandler(this.ExtraVacationlabel1_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(548, 316);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 23;
            // 
            // CheckAcuBonusbutton2
            // 
            this.CheckAcuBonusbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcuBonusbutton2.Location = new System.Drawing.Point(222, 78);
            this.CheckAcuBonusbutton2.Name = "CheckAcuBonusbutton2";
            this.CheckAcuBonusbutton2.Size = new System.Drawing.Size(285, 43);
            this.CheckAcuBonusbutton2.TabIndex = 24;
            this.CheckAcuBonusbutton2.Text = "Click To See Company\'s Hourly Earnings";
            this.CheckAcuBonusbutton2.UseVisualStyleBackColor = true;
            this.CheckAcuBonusbutton2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(409, 402);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 15);
            this.label2.TabIndex = 26;
            this.label2.Text = "Enter Hours Worked Weekly:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(608, 401);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 27;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // calculateptodaysbutton2
            // 
            this.calculateptodaysbutton2.BackColor = System.Drawing.Color.LightCyan;
            this.calculateptodaysbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateptodaysbutton2.Location = new System.Drawing.Point(503, 346);
            this.calculateptodaysbutton2.Name = "calculateptodaysbutton2";
            this.calculateptodaysbutton2.Size = new System.Drawing.Size(133, 53);
            this.calculateptodaysbutton2.TabIndex = 28;
            this.calculateptodaysbutton2.Text = "Calculate Weekly Earned PTO Days";
            this.calculateptodaysbutton2.UseVisualStyleBackColor = false;
            this.calculateptodaysbutton2.Click += new System.EventHandler(this.calculateptodaysbutton2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(740, 514);
            this.Controls.Add(this.calculateptodaysbutton2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CheckAcuBonusbutton2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.ExtraVacationlabel1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.CurrentDatelabel1);
            this.Controls.Add(this.dobdateTimePicker1);
            this.Controls.Add(this.NeedExtraDaysVacationlabel1);
            this.Controls.Add(this.FindOutBonuslabel1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.SalarywithBonuslabel1);
            this.Controls.Add(this.Percentagelabel1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.BonusGuidelabel1);
            this.Controls.Add(this.SalaryDisclosure2label1);
            this.Controls.Add(this.SalaryDisclosure6label1);
            this.Controls.Add(this.SalaryDisclosurelabel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.JackPacklabel1);
            this.Controls.Add(this.VacationDaysbutton1);
            this.Controls.Add(this.EnterYourAgelabel1);
            this.Controls.Add(this.CheckBonusbutton1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Salarylabel1);
            this.Controls.Add(this.MTCTitlebutton);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DarkGreen;
            this.Name = "Form1";
            this.Text = "Moms Talk Crypto Company Benefits";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button MTCTitlebutton;
        private System.Windows.Forms.Label Salarylabel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button CheckBonusbutton1;
        private System.Windows.Forms.Label EnterYourAgelabel1;
        private System.Windows.Forms.Button VacationDaysbutton1;
        private System.Windows.Forms.Label JackPacklabel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label SalaryDisclosurelabel1;
        private System.Windows.Forms.Label SalaryDisclosure6label1;
        private System.Windows.Forms.Label SalaryDisclosure2label1;
        private System.Windows.Forms.Label BonusGuidelabel1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label Percentagelabel1;
        private System.Windows.Forms.Label SalarywithBonuslabel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label FindOutBonuslabel1;
        private System.Windows.Forms.Label NeedExtraDaysVacationlabel1;
        private System.Windows.Forms.DateTimePicker dobdateTimePicker1;
        private System.Windows.Forms.Label CurrentDatelabel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label ExtraVacationlabel1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button CheckAcuBonusbutton2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button calculateptodaysbutton2;
    }
}

